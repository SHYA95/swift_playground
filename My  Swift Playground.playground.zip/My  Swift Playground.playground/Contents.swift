import UIKit
import Foundation
import Darwin
import libkern

// for print in swift
print("You will do well just try!")

//for print interpolation
print("is your day ok ?!\("i am tryng to be ok .")")

//data types
//for int numbers
var v:Int = 1237890;
//UInt n=-3; > that will give an erorr
//for float numbers
var f:Float=1.356773
var d:Double=1.12345678900987
//for caracter and it will be fro kind string
var c:Character = "H"

//type inferance vs type annotation
var g=3
print (type(of: g)) // compiler give the write datatype to the value without any effort of u and that is type inferance

var flag="true" //will be printed right as string
var k:Bool=false //here i must write true or false cuz it is assignsd by me first that is type annotation
//string in swift
var animal="cat"
var anim=String("dog")
//array of character can be used as string in that way
let catchar:[Character]=["c","a","t"]//if i turned to string
let catstring=String(catchar)// it is string

var check = ""
print(check.isEmpty)//give true or false
var countstring = "my name"
print(countstring.count)//space is a character
var string1 = "HI"
var string2 = "SHYA"
//to do concatination
string1 += string2; //without space
print(string1)
//by using append method
string1.append(string2)
// check is equal
if(string2==string1){
    print("true")
}//no print cuz they are not equal


// TUBLES
let http404error = (404,"not found")
print(http404error.0)
let(statcode,_) = http404error
print(statcode)

let http404Error = (statuescode:404, description:"NOT FOUND!?")
print(http404Error.description)

//ARRAYS
let somearray:Array<String> = ["go", "play"]
let anotherarray:[String] = ["go", "play"]
 var firstarray = Array(repeating: 1, count: 3)
var secondarray = Array(repeating: 2, count: 3)
var twoarrays = firstarray + secondarray
print(twoarrays)
  
for i in twoarrays{
    print("the element equal to:\(i)")
}
print(twoarrays[3])
twoarrays.append(9)
print(twoarrays)

var mainlist = ["egg","milk"]
var anotherlist = ["tea","oat"]
mainlist += anotherlist
print(mainlist)
mainlist[0...1] = ["water"]
print(mainlist)

//dictionary
let somedictionary:[String:Int] = ["alex":55,"cat":12]
let anotherdictionary:[String:Int] = ["alex":99,"cat":44]
print(anotherdictionary["alex"])// you will got optional
for (_,value) in anotherdictionary
{
    print(value)
}

//TYPE ALIES
typealias newnames = Dictionary<String,Int>
let medictionary:newnames = ["alex":5,"cat":1]
//print(newnames) here we got an error

//nil is the absent of the value >> - value

//optionals  >>not now

//control flow
//1>if we use it as usual
var nume = 8
if nume%2==0 {
print( true)
}
//2> for we use it like in python
for i in 1...9
{
    print(i)
}
print("------------")
//>reapted while it is like do while in c++
repeat{
    nume*=2
    print(nume)
}while(nume<=100)//need an explanation
print("------------")
//switch case
var count = 2
switch count {
case 0:
    print(0)
case 1:
    print(1)
case 2:
    print(2)
default:
    print("try again")
}
print("------------")
//FUNCTIONS
func iseven(num:Int)->Bool{
    if num%2==0 {
        return true
    }
    return false
}
let x=iseven(num: 5);
let u=iseven(num: 8)
//structs (value type) if 2 obj is equal with different value it will print 2 different
struct Battary{
    var capacity:Int = 1
    var lifetime:Int = 0
}
//CREATING A CLASS(referance type) if 2 obj is equal with different value it will print the same value of the last update

class cars{
    var name:String=""
    var model:Int=0
    var color:String=""
    var speed:Float=1.0
    var battery:Battary = Battary()
    func sentance(){
        print("this car name is \(name) and it is speed is \(speed)")
    }
}
var bmw = cars()
bmw.name="BMW"
bmw.model=2022
bmw.color="black"
bmw.battery.capacity = 4000
bmw.speed=400
bmw.sentance()

//substructs

